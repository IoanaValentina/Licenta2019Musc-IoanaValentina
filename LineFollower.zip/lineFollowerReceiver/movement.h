//enable motors
void enableMotors() {
  digitalWrite(leftInput1,   LOW);
  digitalWrite(leftInput2,  HIGH);
  digitalWrite(rightInput1,  LOW);
  digitalWrite(rightInput2, HIGH);
  delay(delay10);
}
//turn on motors, slow speed
void turnOnMotors() {
  digitalWrite(enableA, 0);
  digitalWrite(enableB, 0);
}
//disable motors
void disableMotors() {
  digitalWrite(leftInput1,   LOW);
  digitalWrite(leftInput2,   LOW);
  digitalWrite(rightInput1,  LOW);
  digitalWrite(rightInput2,  LOW);
  delay(delay10);
}
//move straight, left and right motors at the same slow speed
void moveStraight() {
  Serial.println("Entered moveStraight()");
  digitalWrite(leftInput1,   LOW);
  digitalWrite(leftInput2,  HIGH);
  digitalWrite(rightInput1,  LOW);
  digitalWrite(rightInput2, HIGH);
  Serial.println("Set motor direction");
  analogWrite(enableA, 60);
  analogWrite(enableB, 60);
  Serial.println("Set motor speed");

  Serial.println("moveStraight");
  delay(delay10);
}
void moveBack() {
  digitalWrite(leftInput1,  HIGH);
  digitalWrite(leftInput2,   LOW);
  digitalWrite(rightInput1, HIGH);
  digitalWrite(rightInput2,  LOW);
  analogWrite(enableA, 60);
  analogWrite(enableB, 60);

  Serial.println("moveBack");
  delay(delay10);
}

//steer left - left motors reverse, right motors speed up
void steerLeft() {
  digitalWrite(leftInput1, LOW);
  digitalWrite(leftInput2, HIGH);
  digitalWrite(rightInput1, HIGH);
  digitalWrite(rightInput2, LOW);
  analogWrite(enableA, 85);
  analogWrite(enableB, 85);
  Serial.println("Left Steer");
  delay(10);
}
//steer right - left motors speed up, right motors reverse
void steerRight() {
  digitalWrite(leftInput1, HIGH);
  digitalWrite(leftInput2, LOW);
  digitalWrite(rightInput1, LOW);
  digitalWrite(rightInput2, HIGH);
  analogWrite(enableA, 85);
  analogWrite(enableB, 85);
  Serial.print("Right Steer");
  delay(10);
}

//stop when object is detected
void stopping() {
  analogWrite(enableA, 0);
  analogWrite(enableB, 0);
  Serial.println("stopping !!!");
  stoppingFlag = 1;
  digitalWrite(brake, HIGH);
  delay(10);
}

