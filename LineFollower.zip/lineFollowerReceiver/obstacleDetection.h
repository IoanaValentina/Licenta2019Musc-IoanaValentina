//obstacle detection
bool isBlocked() {
  //clear the trigPin
  digitalWrite(trigPin, LOW);
  delayMicroseconds(delay5);
  //set trigPin on HIGH for 10 microseconds
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(delay10);
  //set trigPin on LOW
  digitalWrite(trigPin, LOW);
  //read echoPin
  duration = pulseIn(echoPin, HIGH);
  //calculate the distance to object
  distance = (duration * distanceFormula);
  //if the distance read from the sensor is greater than the distance set as minimum there is no obstacle
  if (distance > minDistance) {
    //turn brake led off
    //display clear road on Serial Monitor
    obstacle = false;
    digitalWrite(brake, LOW);
    Serial.print("clear road");
  }
  else {
    //if there is an obstacle
    //turn brake led on
    //display obstacle detected on Serial Monitor
    obstacle = true;
    digitalWrite(brake, HIGH);
    Serial.print("obstacle detected ");
  }
  delay(delay5);
  //return if there is an obstacle detected or not
  return obstacle;
}
