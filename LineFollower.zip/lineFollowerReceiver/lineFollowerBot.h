#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>
#include <Servo.h>

RF24 radio(7, 8); // CE, CSN
const byte address[6] = "00001";

bool start = 1;
//communication speed
#define transferSpeed           9600


//delays
#define infraredDelayTime         16
#define delay5                     5
#define delay10                   10
#define delay30                   30
#define delay100                 100
#define startDelay              5000


//infrared sensors
#define leftOutsideSensor         A1
#define leftInsideSensor          10
#define rightOutsideSensor         0
#define rightInsideSensor          9
bool leftOutsideS  = 0;
bool leftInsideS   = 0;
bool rightOutsideS = 0;
bool rightInsideS  = 0;


//servo
#define servoPin                  A2
#define centerPosition           105
//create servo object of type Servo
Servo servo;


//ultrasonic distance sensor
#define trigPin                   A5
#define echoPin                   A4
#define brake                     A0
#define minDistance               30
#define distanceFormula        0.017

bool obstacle = 0;
bool stoppingFlag = 0;
int  distance = 0;
long duration = 0;


//motors
//left motor
#define enableA                     6 //pwm pin
#define leftInput1                  7
#define leftInput2                  5
//right motor
#define enableB                     3 //pwm pin
#define rightInput1                 2
#define rightInput2                 4
//motor speeds
#define maxSpeed                  225
#define minSpeed                   60
#define rectifySpeedValue          20
byte moveSpeed  = 40;
int leftSpeed   =  0;
int rightSpeed  =  0;
byte startSpeed = 40;


// communication
struct information {
  bool keepAlive;
  char trans;
  byte transmit;
};
struct information info;
