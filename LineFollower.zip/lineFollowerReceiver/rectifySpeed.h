//if speed value is below the minimum (40) or above maximum (255)
//it gets rectified to the propper interval so as to not exceet the 256 range of byte

void rectifySpeed() {
  if (stoppingFlag) {
    if (leftSpeed > maxSpeed) {
      leftSpeed -= rectifySpeedValue;
      Serial.println("left speed rectified -20");
      analogWrite(enableA, leftSpeed);
    } else if (leftSpeed < minSpeed) {
      leftSpeed += rectifySpeedValue;
      Serial.println("left speed rectified +20");
      analogWrite(enableA, leftSpeed);
    } else if (rightSpeed > maxSpeed) {
      rightSpeed -= rectifySpeedValue;
      Serial.println("right speed rectified -20");
      analogWrite(enableB, rightSpeed);
    } else if (rightSpeed < minSpeed) {
      rightSpeed += rectifySpeedValue;
      Serial.println("right speed rectified +20");
      analogWrite(enableB, rightSpeed);
    } else {
      //do nothing
    }

  }
  else {
    //do nothing
  }
}

